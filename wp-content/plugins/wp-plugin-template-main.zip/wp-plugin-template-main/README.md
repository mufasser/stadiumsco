# wp-plugin-template
Plugin Template to use as basis for new development. Based on the WordPress plugin boilerplate by Enrique Chávez and Tom McFarlin.

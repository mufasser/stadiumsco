<?php

class Sport extends XS2Event_API {

    private $page; // integer: current page (default: 1)
    private $page_size; // integer: number of items per page (default: 10)
    
    function __construct( ) {
        parent::__construct();
    }

    //setter

    function setPage($page){
        $this->page = $page;
    }

    function setPageSize($pageSize){
        $this->page_size = $pageSize;
    }

    //getters

    function getPage(){
        return $this->page;
    }

    function getPageSize(){
        return $this->page_size;
    }

    function getSports(){

        $data = [];
        if(!empty($this->page)){
            $data['page'] = $this->page;
        }
        if(!empty($this->page_size)){
            $data['page_size'] = $this->page_size;
        }
        $response=  $this->getRequest('/sports', $data);
        return $response;
    }



}
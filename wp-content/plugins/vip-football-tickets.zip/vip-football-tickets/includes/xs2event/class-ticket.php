<?php

class Ticket extends XS2Event_API {


    public $page_size;
    public $page;
    public $ticket_validfrom; // icket_validfrom (yyyy-mm-dd)
    public $ticket_validuntil; // ticket_validuntil (yyyy-mm-dd)
    public $face_value; // face_value for end-customer
    public $stock; // available stock
    public $venue_id; //  venue_id
    public $event_id; //event_id
    public $ticket_type; //ticket_type
    public $city; //city
    public $supplier_type; //supplier_type
    public $supplier_id; //supplier_id
    public $category_id; //category_id
    public $sub_category; //sub category such as sun_regular or weekend_youth
    public $category_type; //category type filtering (generaladmission, grandstand, busparking, carparking, camping, transfer
    public $ticket_status; //ticket_status

    function __construct( ) {
        parent::__construct();
    }

    // setter

    function setPage($page){
        $this->page = $page;
    }

    function setPageSize($pageSize){
        $this->page_size = $pageSize;
    }

    function setTicketValidFrom($ticket_validfrom){
        $this->ticket_validfrom = $ticket_validfrom;
    }

    function setTicketValidUntil($ticket_validuntil){
        $this->ticket_validuntil = $ticket_validuntil;
    }

    function setFaceValue($face_value){
        $this->face_value = $face_value;
    }

    function setStock($stock){
        $this->stock = $stock;
    }

    function setVenueId($venue_id){
        $this->venue_id = $venue_id;
    }

    function setEventId($event_id){
        $this->event_id = $event_id;
    }

    function setTicketType($ticket_type){
        $this->ticket_type = $ticket_type;
    }

    function setCity($city){
        $this->city = $city;
    }

    function setSupplierType($supplier_type){
        $this->supplier_type = $supplier_type;
    }

    function setSupplierId($supplier_id){
        $this->supplier_id = $supplier_id;
    }

    function setCategoryId($category_id){
        $this->category_id = $category_id;
    }

    function setSubCategory($sub_category){
        $this->sub_category = $sub_category;
    }

    function setCategoryType($category_type){
        $this->category_type = $category_type;
    }

    function setTicketStatus($ticket_status){
        $this->ticket_status = $ticket_status;
    }

    // getters

    function getPage(){
        return $this->page;
    }

    function getPageSize(){
        return $this->page_size;
    }

    function getTicketValidFrom(){
        return $this->ticket_validfrom;
    }

    function getTicketValidUntil(){
        return $this->ticket_validuntil;
    }

    function getFaceValue(){
        return $this->face_value;
    }

    function getStock(){
        return $this->stock;
    }

    function getVenueId(){
        return $this->venue_id;
    }

    function getEventId(){
        return $this->event_id;
    }

    function getTicketType(){
        return $this->ticket_type;
    }

    function getCity(){
        return $this->city;
    }

    function getSupplierType(){
        return $this->supplier_type;
    }

    function getSupplierId(){
        return $this->supplier_id;
    }

    function getCategoryId(){
        return $this->category_id;
    }

    function getSubCategory(){
        return $this->sub_category;
    }

    function getCategoryType(){
        return $this->category_type;
    }

    function getTicketStatus(){
        return $this->ticket_status;
    }



     // get remote country list
     function getTickets(){

        $data = [];

        if(!empty($this->getPage())){
            $data['page'] = $this->getPage();
        }
        
        if(!empty($this->getPageSize())){
            $data['page_size'] = $this->getPageSize();
        }

        if(!empty($this->getTicketValidFrom())){
            $data['ticket_validfrom'] = $this->getTicketValidFrom();
        }

        if(!empty($this->getTicketValidUntil())){
            $data['ticket_validuntil'] = $this->getTicketValidUntil();
        }

        if(!empty($this->getFaceValue())){
            $data['face_value'] = $this->getFaceValue();
        }

        if(!empty($this->getStock())){
            $data['stock'] = $this->getStock();
        }

        if(!empty($this->getVenueId())){
            $data['venue_id'] = $this->getVenueId();
        }

        if(!empty($this->getEventId())){
            $data['event_id'] = $this->getEventId();
        }

        if(!empty($this->getTicketType())){
            $data['ticket_type'] = $this->getTicketType();
        }

        if(!empty($this->getCity())){
            $data['city'] = $this->getCity();
        }

        if(!empty($this->getSupplierType())){
            $data['supplier_type'] = $this->getSupplierType();
        }

        if(!empty($this->getSupplierId())){
            $data['supplier_id'] = $this->getSupplierId();
        }

        if(!empty($this->getCategoryId())){
            $data['category_id'] = $this->getCategoryId();
        }

        if(!empty($this->getSubCategory())){
            $data['sub_category'] = $this->getSubCategory();
        }

        if(!empty($this->getCategoryType())){
            $data['category_type'] = $this->getCategoryType();
        }

        if(!empty($this->getTicketStatus())){
            $data['ticket_status'] = $this->getTicketStatus();
        }
        
        
        $response=  $this->getRequest('/tickets', $data);
        return $response;
    }
     function getTicketById($ticketId){

        // $data = ['venue_id'=>$venueId];
        $response=  $this->getRequest('/tickets/'.$ticketId);
        return $response;
    }
    


}
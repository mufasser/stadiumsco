<?php

class Venue extends XS2Event_API {

    function __construct( ) {
        parent::__construct();
    }

     // get remote country list
     function getVenues($country='', $venue_type='', $venue_name='', $slug='', $onlyPopularStadiums=true, $page=1, $pageSize=100){

        $data = ['page'=>$page, "page_size"=> $pageSize];

        if(!empty($country)){
            $data['country'] = $country;
        }
        if(!empty($venue_type)){
            $data['venue_type'] = $venue_type;
        }
        if(!empty($venue_name)){
            $data['venue_name'] = $venue_name;
        }

        if(!empty($slug)){
            $data['slug'] = $slug;
        }
        if(!empty($onlyPopularStadiums)){
            $data['popular'] = $onlyPopularStadiums;
        }
        
        $response=  $this->getRequest('/venues', $data);
        return $response;
    }
     function getVenueById($venueId){

        // $data = ['venue_id'=>$venueId];
        $response=  $this->getRequest('/venues/'.$venueId);
        return $response;
    }

}
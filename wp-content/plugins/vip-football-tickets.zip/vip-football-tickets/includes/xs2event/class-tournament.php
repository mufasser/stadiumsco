<?php

class Tournament extends XS2Event_API {

    public $page_size; // integer: number of items per page (default: 10)
    public $page; // integer: current page (default: 1)
    public $region; // string: iso country. For F1/Moto use "world"
    public $date_start; // string: date start
    public $date_stop; // string: date_stop
    public $sport_type; // string: soccer, motogp, tennis,rugby, darts, boxing, formula1
    public $tournament_type; // string: tournament_type league cup
    public $tournament_name; // string: tournament name

    function __construct( ) {
        parent::__construct();
    }

    // setter

    function setPage($page){
        $this->page = $page;
    }

    function setPageSize($pageSize){
        $this->page_size = $pageSize;
    }

    function setRegion($region){
        $this->region = $region;
    }

    function setDateStart($date_start){
        $this->date_start = $date_start;
    }

    function setDateStop($date_stop){
        $this->date_stop = $date_stop;
    }

    function setSportType($sport_type){
        $this->sport_type = $sport_type;
    }

    function setTournamentType($tournament_type){
        $this->tournament_type = $tournament_type;
    }

    function setTournamentName($tournament_name){
        $this->tournament_name = $tournament_name;
    }


    // getters
    function getPage(){
        return $this->page;
    }

    function getPageSize(){
        return $this->page_size;
    }

    function getRegion(){
        return $this->region;
    }

    function getDateStart(){
        return $this->date_start;
    }

    function getDateStop(){
        return $this->date_stop;
    }

    function getSportType(){
        return $this->sport_type;
    }

    function getTournamentType(){
        return $this->tournament_type;
    }

    function getTournamentName(){
        return $this->tournament_name;
    }

     // get remote country list
     function getTournaments(){

        $data = [];

        if(!empty($this->getPage())){
            $data['page'] = $this->getPage();
        }
        
        if(!empty($this->getPageSize())){
            $data['page_size'] = $this->getPageSize();
        }

        if(!empty($this->getRegion())){
            $data['region'] = $this->getRegion();
        }

        if(!empty($this->getDateStart())){
            $data['date_start'] = $this->getDateStart();
        }

        if(!empty($this->getDateStop())){
            $data['date_stop'] = $this->getDateStop();
        }

        if(!empty($this->getSportType())){
            $data['sport_type'] = $this->getSportType();
        }

        if(!empty($this->getTournamentType())){
            $data['tournament_type'] = $this->getTournamentType();
        }

        if(!empty($this->getTournamentName())){
            $data['tournament_name'] = $this->getTournamentName();
        }

        
        
        $response=  $this->getRequest('/tournaments', $data);
        return $response;
    }
     function getTournamentById($tournamentId){

        // $data = ['venue_id'=>$venueId];
        $response=  $this->getRequest('/tournaments/'.$tournamentId);
        return $response;
    }

    
}
<?php

class Team extends XS2Event_API {

    public int $page_size; // integer: number of items per page (default: 10)
    public int $page; // integer: current page (default: 1)
    public int $team_slug; // integer: slug of the team according to https://liaison.reuters.com/tools/sports-team-codes
    public string $team_name; // string: name of the club
    public bool $popular; // boolean: show popular clubs (most bookings)
    public bool $club_logo; // boolean: show teams with club logo
    public string $sport_type; // string: sport type (soccer, tennis, motorsport, darts, rugby, etc etc)
    public string $slug; // string: seo friendly alternative to uuid
    public string $iso_country; // string: filter teams on their (ISO 3166-1 alpha-3) country of origin
    public string $event_startdate; // string: Only returns teams which are linked to events with a startdate matching this criteria
    public bool $interesting; // boolean: filter interesting teams

    function __construct( ) {
        parent::__construct();
    }

    // setter

    function setPage($page){
        $this->page = $page;
    }

    function setPageSize($pageSize){
        $this->page_size = $pageSize;
    }

    function setTeamSlug($team_slug){
        $this->team_slug = $team_slug;
    }

    function setTeamName($team_name){
        $this->team_name = $team_name;
    }

    function setPopular($popular){
        $this->popular = $popular;
    }

    function setClubLogo($club_logo){
        $this->club_logo = $club_logo;
    }

    function setSportType($sport_type){
        $this->sport_type = $sport_type;
    }

    function setSlug($slug){
        $this->slug = $slug;
    }

    function setIsoCountry($iso_country){
        $this->iso_country = $iso_country;
    }

    function setEventStartdate($event_startdate){
        $this->event_startdate = $event_startdate;
    }

    function setInteresting($interesting){
        $this->interesting = $interesting;
    }

    // GETTERS

    function getPage(){
        return $this->page;
    }

    function getPageSize(){
        return $this->page_size;
    }

    function getTeamSlug(){
        return $this->team_slug;
    }

    function getTeamName(){
        return $this->team_name;
    }

    function getPopular(){
        return $this->popular;
    }

    function getClubLogo(){
        return $this->club_logo;
    }

    function getSportType(){
        return $this->sport_type;
    }

    function getSlug(){
        return $this->slug;
    }

    function getIsoCountry(){
        return $this->iso_country;
    }

    function getEventStartdate(){
        return $this->event_startdate;
    }

    function getInteresting(){
        return $this->interesting;
    }
    


     // get remote country list
     function getTournaments(){

        $data = [];

        if(!empty($this->getPage())){
            $data['page'] = $this->getPage();
        }
        
        if(!empty($this->getPageSize())){
            $data['page_size'] = $this->getPageSize();
        }

        if(!empty($this->getTeamSlug())){
            $data['team_slug'] = $this->getTeamSlug();
        }

        if(!empty($this->getTeamName())){
            $data['team_name'] = $this->getTeamName();
        }

        if(!empty($this->getPopular())){
            $data['popular'] = $this->getPopular();
        }

        if(!empty($this->getClubLogo())){
            $data['club_logo'] = $this->getClubLogo();
        }

        if(!empty($this->getSportType())){
            $data['sport_type'] = $this->getSportType();
        }

        if(!empty($this->getSlug())){
            $data['slug'] = $this->getSlug();
        }

        if(!empty($this->getIsoCountry())){
            $data['iso_country'] = $this->getIsoCountry();
        }

        if(!empty($this->getEventStartdate())){
            $data['event_startdate'] = $this->getEventStartdate();
        }

        if(!empty($this->getInteresting())){
            $data['interesting'] = $this->getInteresting();
        }


        
        
        $response=  $this->getRequest('/teams', $data);
        return $response;
    }
     function getTeamById($teamId){

        // $data = ['venue_id'=>$venueId];
        $response=  $this->getRequest('/teams/'.$teamId);
        return $response;
    }

    
}